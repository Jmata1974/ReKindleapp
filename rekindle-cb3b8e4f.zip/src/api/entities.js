import { base44 } from './base44Client';


export const Contact = base44.entities.Contact;

export const Achievement = base44.entities.Achievement;

export const UserStats = base44.entities.UserStats;



// auth sdk:
export const User = base44.auth;